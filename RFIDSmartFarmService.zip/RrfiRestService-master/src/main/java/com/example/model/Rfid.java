/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author vladimir
 */
@Entity(name = "Rfid")
@Table(name = "rfid")
public class Rfid implements Serializable {

    private int rfid_id;
    private String rfid;
    private String name;
    private int stala;
    private Date date;

    public Rfid() {
    }

    public Rfid(int rfid_id, String rfid, String name, int stala, Date date) {
        this.rfid_id = rfid_id;
        this.rfid = rfid;
        this.name = name;
        this.stala = stala;
        this.date = date;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "rfid_id")
    public int getRfid_id() {
        return rfid_id;
    }

    public void setRfid_id(int rfid_id) {
        this.rfid_id = rfid_id;
    }

    @Column(name = "rfid")
    public String getRfid() {
        return rfid;
    }

    public void setRfid(String rfid) {
        this.rfid = rfid;
    }

    @Column(name = "name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column(name = "date")
    @Temporal(TemporalType.TIMESTAMP)
    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
    
    @Column(name = "stala")
    public int getStala() {
        return stala;
    }

    public void setStala(int stala) {
        this.stala = stala;
    }

}
