/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author vladimir
 */
@Entity(name = "TempHumidity")
@Table(name = "temphumidity")
public class TempHumidity {

    private int id;
    private Date date;
    private String temperatura;
    private String vlaznost;

    public TempHumidity() {
    }

    public TempHumidity(Date date, String temperatura, String vlaznost) {
        this.date = date;
        this.temperatura = temperatura;
        this.vlaznost = vlaznost;
    }

    @Column(name = "vlaznost")
    public String getVlaznost() {
        return vlaznost;
    }

    public void setVlaznost(String vlaznost) {
        this.vlaznost = vlaznost;
    }

    @Column(name = "datum")
    @Temporal(TemporalType.TIMESTAMP)
    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Column(name = "temperatura")
    public String getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(String temperatura) {
        this.temperatura = temperatura;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

}
