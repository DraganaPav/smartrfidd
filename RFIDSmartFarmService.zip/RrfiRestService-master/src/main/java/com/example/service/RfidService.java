/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.service;

import com.example.model.Rfid;
import com.example.repository.RfidRepository;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author vladimir
 */
@Service
public class RfidService {

    @Autowired
    private RfidRepository rfidRepository;

    public List<Rfid> getAll() {
        List<Rfid> rfids = new ArrayList<>();
        rfidRepository.findAll()
                .forEach(rfid -> rfids.add(rfid));
        return rfids;
    }

    public Rfid getRfid(String rfid) {
        return (Rfid) rfidRepository.findByRfid(rfid);
    }

    public void insertRfid(String rfid_id, String name) {
        Rfid rfidExist = rfidRepository.findByRfid(rfid_id);
        if (rfidExist != null) {
            if (rfidExist.getStala() == 0) {
                rfidExist.setStala(1);
                rfidExist.setDate(new Date());
            } else {
                rfidExist.setStala(0);
                rfidExist.setDate(new Date());
            }
            rfidRepository.save(rfidExist);
//            return rfidExist;
        } else {
            Rfid rfid = new Rfid();
            rfid.setDate(new Date());
            rfid.setName(name);
            rfid.setRfid(rfid_id);
            rfid.setStala(1);
            rfidRepository.save(rfid);
//            return rfid;
        }
    }
}
