/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.service;

import com.example.model.TempHumidity;
import com.example.repository.TempHumidityRepository;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author vladimir
 */
@Service
public class TempHumidityService {

    @Autowired
    private TempHumidityRepository tempHumidityRepository;

    public List<TempHumidity> getAll() {
        List<TempHumidity> temphumidities = new ArrayList<>();
        tempHumidityRepository.findAll()
                .forEach(temphumi -> temphumidities.add(temphumi));
        return temphumidities;
    }
    
    public TempHumidity getLatest() {
        return tempHumidityRepository.findFirstByOrderByIdDesc();
    } 

    public void insert(String temperatura, String vlaznost) {
        TempHumidity tempHumidity = new TempHumidity(new Date(), temperatura, vlaznost);
        tempHumidityRepository.save(tempHumidity);
    }

}
