/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.controller;

import com.example.model.TempHumidity;
import com.example.service.TempHumidityService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author vladimir
 */
@RestController
@RequestMapping(value = "api/temphumidity", produces = "application/json")
public class TempHumidityController {

    @Autowired
    private TempHumidityService tempHumidityService;

    @RequestMapping(method = RequestMethod.GET, value = "/all")
    public List<TempHumidity> getAllTempHumidity() {
        return tempHumidityService.getAll();
    }
    
    @RequestMapping(method = RequestMethod.GET, value = "/latest")
    public TempHumidity getLatest() {
        return tempHumidityService.getLatest();
    }

    @RequestMapping(method = RequestMethod.GET, value = "", produces = "application/json")
    private void insertRfid(@RequestParam(value = "temperatura", required = true) String temperatura,
            @RequestParam(value = "vlaznost", required = true) String vlaznost) {
        tempHumidityService.insert(temperatura, vlaznost);
    }
}
