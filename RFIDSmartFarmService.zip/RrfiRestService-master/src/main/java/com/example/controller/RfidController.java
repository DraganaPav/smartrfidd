/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.controller;

import com.example.model.Rfid;
import com.example.service.RfidService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author vladimir
 */
@RestController
@RequestMapping(value = "api/rfid", produces = "application/json")
public class RfidController {

    @Autowired
    private RfidService rfidService;

    @RequestMapping(method = RequestMethod.GET, value = "/all")
    public List<Rfid> getAllRfids() {
        return rfidService.getAll();
    }

    @RequestMapping(method = RequestMethod.GET, value = "/{rfid}")
    private Rfid getRfid(@PathVariable String rfid) {
        return rfidService.getRfid(rfid);
    }

    @RequestMapping(method = RequestMethod.GET, value = "", produces = "application/json")
    private void insertRfid(@RequestParam(value = "rfid_id", required = true) String rfid_id,
            @RequestParam(value = "name", required = true) String name) {
        rfidService.insertRfid(rfid_id, name);
    }
}
